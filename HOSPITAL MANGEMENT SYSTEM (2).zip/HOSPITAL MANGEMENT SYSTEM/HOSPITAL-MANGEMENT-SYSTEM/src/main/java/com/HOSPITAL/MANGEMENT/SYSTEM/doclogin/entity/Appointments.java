package com.HOSPITAL.MANGEMENT.SYSTEM.doclogin.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Appointments")
public class Appointments 
{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    private String name;
    private String age;
    private String gender;
    private String symptoms;
    private String number;
    private String date;
    private String time;
    private String doctor;

    public Appointments() 
    {
        super();
    }

    public Appointments(long id, String name, String age, String gender, String symptoms,
                        String number, String date, String time, String doctor)
    {
        this.id = id;
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.symptoms = symptoms;
        this.number = number;
        this.date = date;
        this.time = time;
        this.doctor = doctor;
    }

    // Getters and setters

    public long getId() { return id; }

    public void setId(long id) { this.id = id; }

    public String getName() { return name; }

    public void setName(String name) { this.name = name; }

    public String getAge() { return age; }

    public void setAge(String age) { this.age = age; }

    public String getGender() { return gender; }

    public void setGender(String gender) { this.gender = gender; }

    public String getSymptoms() { return symptoms; }

    public void setSymptoms(String symptoms) { this.symptoms = symptoms; }

    public String getNumber() { return number; }

    public void setNumber(String number) { this.number = number; }

    public String getDate() { return date; }

    public void setDate(String date) { this.date = date; }

    public String getTime() { return time; }

    public void setTime(String time) { this.time = time; }

    public String getDoctor() { return doctor; }

    public void setDoctor(String doctor) { this.doctor = doctor; }
}
