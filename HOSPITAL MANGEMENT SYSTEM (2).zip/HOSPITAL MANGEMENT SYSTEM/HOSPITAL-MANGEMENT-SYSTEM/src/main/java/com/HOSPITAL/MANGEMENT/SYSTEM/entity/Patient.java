package com.HOSPITAL.MANGEMENT.SYSTEM.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "patients")
public class Patient {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "first_name")
    private String name;

    @Column(name = "age")
    private String age;

    @Column(name = "gender")
    private String gender;

    @Column(name = "blood_group")
    private String bloodGroup;  // ✅ FIXED: matches DB column

    @Column(name = "fees")
    private String fees;

    @Column(name = "urgency")
    private String urgency;

    @Column(name = "symptoms")
    private String symptoms;

    @Column(name = "number")
    private String number;

    @Column(name = "date")
    private String date;

    @Column(name = "time")
    private String time;

    @Column(name = "doctor")
    private String doctor;

    public Patient() {}

    public Patient(long id, String name, String age, String gender, String bloodGroup,
                   String fees, String urgency, String symptoms, String number,
                   String date, String time, String doctor) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.bloodGroup = bloodGroup;
        this.fees = fees;
        this.urgency = urgency;
        this.symptoms = symptoms;
        this.number = number;
        this.date = date;
        this.time = time;
        this.doctor = doctor;
    }

    // ✅ Getters and Setters

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getAge() { return age; }
    public void setAge(String age) { this.age = age; }

    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }

    public String getBloodGroup() { return bloodGroup; }
    public void setBloodGroup(String bloodGroup) { this.bloodGroup = bloodGroup; }

    public String getFees() { return fees; }
    public void setFees(String fees) { this.fees = fees; }

    public String getUrgency() { return urgency; }
    public void setUrgency(String urgency) { this.urgency = urgency; }

    public String getSymptoms() { return symptoms; }
    public void setSymptoms(String symptoms) { this.symptoms = symptoms; }

    public String getNumber() { return number; }
    public void setNumber(String number) { this.number = number; }

    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }

    public String getTime() { return time; }
    public void setTime(String time) { this.time = time; }

    public String getDoctor() { return doctor; }
    public void setDoctor(String doctor) { this.doctor = doctor; }
}
