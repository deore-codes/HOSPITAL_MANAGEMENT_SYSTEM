package com.HOSPITAL.MANGEMENT.SYSTEM.controller;


import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.HOSPITAL.MANGEMENT.SYSTEM.entity.Patient;
import com.HOSPITAL.MANGEMENT.SYSTEM.repository.PatientRepository;


import javax.management.AttributeNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;



@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/v1")//API and V stands for version
public class PatientController 
{

    @Autowired
    private PatientRepository patientRepository;

    // Create Patient
    @PostMapping("/insert")
    public Patient createPatient(@RequestBody Patient patient) 
    {
        return patientRepository.save(patient);
    }

    // Get All Patients
    @GetMapping("/patients")
    public List<Patient> getAllPatients() {
        return patientRepository.findAll();
    }

    // Get Patient by ID
    @GetMapping("/patients/{id}")
    public ResponseEntity<Patient> getPatientById(@PathVariable Long id) throws AttributeNotFoundException {
        Patient patient = patientRepository.findById(id)
                .orElseThrow(() -> new AttributeNotFoundException("Patient not found with ID: " + id));
        return ResponseEntity.ok(patient);
    }

    // Update Patient
    @PutMapping("/patients/{id}")
    public ResponseEntity<Patient> updatePatient(@PathVariable Long id, @RequestBody Patient patientDetails)
            throws AttributeNotFoundException {

        Patient patient = patientRepository.findById(id)
                .orElseThrow(() -> new AttributeNotFoundException("Patient not found with ID: " + id));

        patient.setName(patientDetails.getName());
        patient.setAge(patientDetails.getAge());
        patient.setGender(patientDetails.getGender());
        patient.setNumber(patientDetails.getNumber());

        Patient updatedPatient = patientRepository.save(patient);
        return ResponseEntity.ok(updatedPatient);
    }

    // Delete Patient
    @DeleteMapping("/patients/{id}")
    public ResponseEntity<Map<String, Boolean>> deletePatient(@PathVariable Long id)
            throws AttributeNotFoundException {

        Patient patient = patientRepository.findById(id)
                .orElseThrow(() -> new AttributeNotFoundException("Patient not found with ID: " + id));

        patientRepository.delete(patient);
        Map<String, Boolean> response = new HashMap<>();
        response.put("deleted", Boolean.TRUE);
        return ResponseEntity.ok(response);
    }
}
