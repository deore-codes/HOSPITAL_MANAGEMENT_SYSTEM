package com.HOSPITAL.MANGEMENT.SYSTEM.doclogin.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "medicine")
public class Medicine {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "drug_name")
    private String drugName;

    private String stock;

    @Column(name = "expiry_date")
    private String expiryDate; // Or use java.sql.Date if needed

    private String manufacturer;

    private Double price; // Use wrapper class to allow null

    private Integer quantity; // Use wrapper class to allow null

    // ----------------------
    // ✅ Getters and Setters
    // ----------------------

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDrugName() {
        return drugName;
    }

    public void setDrugName(String drugName) {
        this.drugName = drugName;
    }

    public String getStock() {
        return stock;
    }

    public void setStock(String stock) {
        this.stock = stock;
    }

    public String getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    // Optional: toString()
    @Override
    public String toString() {
        return "Medicine{" +
                "id=" + id +
                ", drugName='" + drugName + '\'' +
                ", stock='" + stock + '\'' +
                ", expiryDate='" + expiryDate + '\'' +
                ", manufacturer='" + manufacturer + '\'' +
                ", price=" + price +
                ", quantity=" + quantity +
                '}';
    }
	
    
    
}
