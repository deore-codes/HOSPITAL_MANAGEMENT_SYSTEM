package com.HOSPITAL.MANGEMENT.SYSTEM.docloginController;

import java.util.List;
import java.util.Optional;

import javax.management.AttributeNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.HOSPITAL.MANGEMENT.SYSTEM.doclogin.entity.Medicine;
import com.HOSPITAL.MANGEMENT.SYSTEM.doclogin.repository.MedicineRepository;

import jakarta.persistence.EntityNotFoundException;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/v3")
public class MedicineController 
{

    @Autowired
    private MedicineRepository medicineRepository;

    // ✅ Add New Medicine
    @PostMapping("/medicines")
    public ResponseEntity<Medicine> createMedicine(@RequestBody Medicine medicine) {
        return ResponseEntity.ok(medicineRepository.save(medicine));
        
    }

    // ✅ Get All Medicines
    @GetMapping("/medicines")
    public List<Medicine> getAllMedicine() 
    {
        return medicineRepository.findAll();
    }

//    // ✅ Get Medicine By ID
//    @GetMapping("/medicines/{id}")
//    public ResponseEntity<Medicine> getMedicineById(@PathVariable long id) 
//    {
//        Medicine medicine = medicineRepository.findById(id)
//                .orElseThrow(() -> new EntityNotFoundException("Medicine not found with ID: " + id));
//        return ResponseEntity.ok(medicine);
//    }

    @GetMapping("/medicines/{id}")
    public ResponseEntity<Medicine> getMedicineById1(@PathVariable long id) throws AttributeNotFoundException {
        Medicine medicine = medicineRepository.findById(id)
            .orElseThrow(() -> new AttributeNotFoundException("Medicine not found with id: " + id));
        return ResponseEntity.ok(medicine);
    }


    
    @PutMapping("/medicines/{id}")
    public ResponseEntity<Medicine> updateMedicine(@PathVariable long id, @RequestBody Medicine medicineDetails) throws AttributeNotFoundException {
        Medicine medicine = medicineRepository.findById(id)
            .orElseThrow(() -> new AttributeNotFoundException("Medicine not found with id: " + id));

        medicine.setDrugName(medicineDetails.getDrugName());
        medicine.setStock(medicineDetails.getStock());
        medicine.setManufacturer(medicineDetails.getManufacturer());
        medicine.setExpiryDate(medicineDetails.getExpiryDate());
        medicine.setPrice(medicineDetails.getPrice());
        medicine.setQuantity(medicineDetails.getQuantity());

        Medicine updatedMedicine = medicineRepository.save(medicine);

        return ResponseEntity.ok(updatedMedicine);
    }
  

    // ✅ Delete Medicine By ID
    @DeleteMapping("/medicines/{id}")
    public ResponseEntity<String> deleteMedicine(@PathVariable long id) 
    {
        Medicine medicine = medicineRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Medicine not found with ID: " + id));
        medicineRepository.delete(medicine);
        return ResponseEntity.ok("Medicine with ID " + id + " deleted successfully.");
    }
}
