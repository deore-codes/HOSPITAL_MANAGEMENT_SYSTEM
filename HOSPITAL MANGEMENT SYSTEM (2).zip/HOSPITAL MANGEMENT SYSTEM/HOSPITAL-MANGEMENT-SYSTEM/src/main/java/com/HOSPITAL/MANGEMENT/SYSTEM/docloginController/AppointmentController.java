package com.HOSPITAL.MANGEMENT.SYSTEM.docloginController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.management.AttributeNotFoundException;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.HOSPITAL.MANGEMENT.SYSTEM.doclogin.entity.Appointments;
import com.HOSPITAL.MANGEMENT.SYSTEM.doclogin.repository.AppointmentsRepository;

@CrossOrigin(origins = "http://localhost:4200")
// ✅ Required for Angular to call API
@RestController
@RequestMapping("/api/v2/appointments")  // full path becomes: http://localhost:8080/api/v2/appointments

public class AppointmentController 
{
	AppointmentsRepository appointmentsRepository;

	public AppointmentController(AppointmentsRepository appointmentsRepository) {
		super();
		this.appointmentsRepository = appointmentsRepository;
	}
	
	@PostMapping("/insert")
	public Appointments createAppointment(@RequestBody Appointments appointment)
	{
		return appointmentsRepository.save(appointment);
	}
	
	@GetMapping
	public List<Appointments>getAllAppointments()
	{
		return appointmentsRepository.findAll();
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<Map<String, Boolean>> deleteAppointment(@PathVariable Long id) throws AttributeNotFoundException
	{
	    Appointments appointment = appointmentsRepository.findById(id)
	        .orElseThrow(() -> new AttributeNotFoundException("Appointment not found with id " + id));

	    appointmentsRepository.delete(appointment);
	    Map<String, Boolean> response = new HashMap<>();
	    response.put("deleted", Boolean.TRUE);

	    return ResponseEntity.ok(response);
	}


}
