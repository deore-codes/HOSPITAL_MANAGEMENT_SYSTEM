package com.HOSPITAL.MANGEMENT.SYSTEM.doclogin.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.HOSPITAL.MANGEMENT.SYSTEM.doclogin.entity.Appointments;

@Repository
public interface AppointmentsRepository extends JpaRepository<Appointments, Long>
{

}
